package com.example.tap2024

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
